function getDefaultProperty(index) {
    return {
        trackerTarget: "a" + (index + 1),
        trackable: null,
        appearingAnimation: null,
        rotationAnimation: null,

        buttonRotate: null,
        buttonAssembly: null,
        buttonHistory: null,
        buttonDrawing: null
    }
}
