var baseUrl = "http://10.10.8.33:8080/content/style/"
var count = 2;

var World = {
	loaded: false,
	rotating: false,
	trackableVisible: false,
	snapped: false,
	resourcesLoaded: false,
	interactionContainer: 'snapContainer',
	layout: {
		normal: {
			offsetX: 0.35,
			offsetY: 0.45,
			opacity: 0.0,
			carScale: 0.105,
			carTranslateY: 0.05
		},
		snapped: {
			offsetX: 0.45,
			offsetY: 0.45,
			opacity: 0.2,
			carScale: 0.105,
			carTranslateY: 0
		}
	},
	previousDragValue: { x: 0, y: 0 },
	previousScaleValue: 0,
	previousScaleValueButtons: 0,

	previousScaleValueButtonAssembly: 0,
	previousScaleValueButtonHistory: 0,
	previousScaleValueButtonDrawing: 0,
	previousScaleValueButtonDiassembly: 0,

	previousRotationValue: 0,

	previousTranslateValueRotate: { x: 0, y: 0 },
	previousTranslateValueSnap: { x: 0, y: 0 },
	previousTranslateValueAssembly: { x: 0, y: 0 },
	previousTranslateValueDiassembly: { x: 0, y: 0 },
	previousTranslateValueHistory: { x: 0, y: 0 },
	previousTranslateValueDrawing: { x: 0, y: 0 },

	defaultScale: 0,

	init: function initFn() {
		this.createOverlays(baseUrl);
	},

	createOverlays: function createOverlaysFn(baseUrl) {
		targetCollectionResource(baseUrl);
		World.modelObjects=[];
		initilizeModel(baseUrl);
		
		dismissBtn = function () {
			console.log("dismiss btn clicked")
			document.getElementById('imgContainer').style.visibility = "hidden";
		}	
	},



	toggleAnimateModel: function toggleAnimateModelFn() {
		if (!World.rotationAnimation.isRunning()) {
			if (!World.rotating) {
				// Starting an animation with .start(-1) will loop it indefinitely.
				World.rotationAnimation.start(-1);
				World.rotating = true;
			} else {
				// Resumes the rotation animation
				World.rotationAnimation.resume();
			}
		} else {
			// Pauses the rotation animation
			World.rotationAnimation.pause();
		}

		return false;
	},


	
	onScaleBegan: function (scale) {
		if (World.snapped) {
			World.previousScaleValue = World.modelCar.scale.x;
			World.previousScaleValueButtons = World.buttonRotate.scale.x;
			World.previousScaleValueButtonAssembly = World.buttonAssembly.scale.x;
			World.previousScaleValueButtonHistory = World.buttonHistory.scale.x;
			World.previousScaleValueButtonDiassembly = World.buttonDiassembly.scale.x;
			World.previousScaleValueButtonDrawing = World.buttonDrawing.scale.x;


			World.previousTranslateValueRotate.x = World.buttonRotate.translate.x;
			World.previousTranslateValueRotate.y = World.buttonRotate.translate.y;

			// World.previousTranslateValueSnap.x = World.buttonSnap.translate.x;
			// World.previousTranslateValueSnap.y = World.buttonSnap.translate.x;

			World.previousTranslateValueAssembly.x = World.buttonAssembly.translate.x;
			World.previousTranslateValueAssembly.y = World.buttonAssembly.translate.x;

			World.previousTranslateValueDiassembly.x = World.buttonDiassembly.translate.x;
			World.previousTranslateValueDiassembly.y = World.buttonDiassembly.translate.x;

			World.previousTranslateValueHistory.x = World.buttonHistory.translate.x;
			World.previousTranslateValueHistory.y = World.buttonHistory.translate.x;

			World.previousTranslateValueDrawing.x = World.buttonDrawing.translate.x;
			World.previousTranslateValueDrawing.y = World.buttonDrawing.translate.x;
		}
	},
	onScaleChanged: function (scale) {
		if (World.snapped) {

			World.modelCar.scale.x = World.previousScaleValue * scale;
			World.modelCar.scale.y = World.modelCar.scale.x;
			World.modelCar.scale.z = World.modelCar.scale.x;

			World.buttonRotate.scale.x = World.previousScaleValueButtons * scale;
			World.buttonRotate.scale.y = World.buttonRotate.scale.x;

			// World.buttonSnap.scale.x = World.buttonRotate.scale.x;
			// World.buttonSnap.scale.y = World.buttonRotate.scale.x;

			World.buttonAssembly.scale.x = World.previousScaleValueButtonAssembly * scale;
			World.buttonAssembly.scale.y = World.buttonAssembly.scale.x;

			World.buttonDiassembly.scale.x = World.previousScaleValueButtonDiassembly * scale;
			World.buttonDiassembly.scale.y = World.buttonDiassembly.scale.x;

			World.buttonHistory.scale.x = World.previousScaleValueButtonHistory * scale;
			World.buttonHistory.scale.y = World.buttonHistory.scale.x;

			World.buttonDrawing.scale.x = World.previousScaleValueButtonDrawing * scale;
			World.buttonDrawing.scale.y = World.buttonDrawing.scale.x;




			World.buttonRotate.translate.x = World.previousTranslateValueRotate.x * scale;
			World.buttonRotate.translate.y = World.previousTranslateValueRotate.y * scale;

			// World.buttonSnap.translate.x = World.previousTranslateValueSnap.x * scale;
			// World.buttonSnap.translate.y = World.previousTranslateValueSnap.y * scale;

			World.buttonAssembly.translate.x = World.previousTranslateValueAssembly.x * scale;
			World.buttonAssembly.translate.y = World.previousTranslateValueAssembly.y * scale;

			World.buttonDiassembly.translate.x = World.previousTranslateValueDiassembly.x * scale;
			World.buttonDiassembly.translate.y = -World.previousTranslateValueDiassembly.y * scale;

			World.buttonHistory.translate.x = World.previousTranslateValueHistory.x * scale;
			World.buttonHistory.translate.y = -World.previousTranslateValueHistory.y * scale;

			World.buttonDrawing.translate.x = World.previousTranslateValueDrawing.x * scale;
			World.buttonDrawing.translate.y = World.previousTranslateValueDrawing.y * scale;
		}
	}

};

World.init();
