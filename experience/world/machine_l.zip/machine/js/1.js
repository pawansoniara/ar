var targetCollectionResource=null;

function intilizeTracker(baseURL){
    targetCollectionResource=new AR.TargetCollectionResource(baseURL + "tracker.wtc", {
			onLoaded: function () {
				World.resourcesLoaded = true;
				World.loadingStep();
			},
			onError: function (errorMessage) {
				alert(errorMessage);
			}
		});


    World.tracker = new AR.ImageTracker(targetCollectionResource, {
        onTargetsLoaded: World.loadingStep,
        onError: function (errorMessage) {
            alert(errorMessage);
        }
    });
}