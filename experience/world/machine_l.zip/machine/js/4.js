function displayTrackerFn(modelObject) {
		
			console.log("displayTrackerFn",modelObject.property.trackerTarget);
			
			modelObject.property.trackable = new AR.ImageTrackable(this.tracker, modelObject.property.trackerTarget, {
				drawables: {
					cam: [modelObject.model, modelObject.property.buttonRotate, modelObject.property.buttonAssembly, modelObject.property.buttonDiassembly, modelObject.property.buttonHistory, modelObject.property.buttonDrawing]
				},
				snapToScreen: {
					snapContainer: document.getElementById('snapContainer')
				},
				onImageRecognized: this.appear,
				onImageLost: this.disappear,
				onError: function (errorMessage) {
					alert(errorMessage);
				}
			});
			console.log("displayTrackerFn finished");

	}