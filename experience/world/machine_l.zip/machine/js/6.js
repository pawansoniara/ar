
function loadingStep() {
		//World.appearingAnimation.start();
		// if (World.resourcesLoaded && World.modelCar.isLoaded()) {

		// 	if (World.trackableVisible && !World.appearingAnimation.isRunning()) {
		// 		World.appearingAnimation.start();
		// 	}

		// 	var cssDivLeft = " style='display: table-cell;vertical-align: middle; text-align: right; width: 50%; padding-right: 15px;'";
		// 	var cssDivRight = " style='display: table-cell;vertical-align: middle; text-align: left;'";
		// 	document.getElementById('loadingMessage').innerHTML =
		// 		"<div" + cssDivLeft + ">Scan CarAd ClientTracker Image:</div>" +
		// 		"<div" + cssDivRight + "><img src='assets/car.png'></img></div>";
		// }
	}


function removeLoadingBar () {
		// if (!World.loaded && World.resourcesLoaded && World.modelCar.isLoaded()) {
		// 	var e = document.getElementById('loadingMessage');
		// 	e.parentElement.removeChild(e);
		// 	World.loaded = true;
		// }
			World.loaded = true;
	}


function appear() {
		console.log(appear);
		World.removeLoadingBar();
		World.trackableVisible = true;
		if (World.loaded && !World.snapped) {
			// Resets the properties to the initial values.
			World.resetModel();
			World.appearingAnimation.start();
		}
	}
function disappear() {
		World.trackableVisible = false;
	}

function resetModel() {
		World.rotationAnimation.stop();
		World.rotating = false;
		World.modelCar.rotate.x = 0;
		World.modelCar.rotate.y = 0;
		World.modelCar.rotate.z = 105;
	}

function toggleSnapping() {

		if (World.appearingAnimation.isRunning()) {
			World.appearingAnimation.stop();
		}
		World.snapped = !World.snapped;
		World.trackable.snapToScreen.enabled = World.snapped;

		if (World.snapped) {
			World.applyLayout(World.layout.snapped);

		} else {
			World.applyLayout(World.layout.normal);
		}
	}